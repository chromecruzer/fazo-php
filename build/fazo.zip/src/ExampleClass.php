<?php
namespace Fazoacademy\Learn;

class ExampleClass {
    public function doSomething() {
        echo "Doing something from ExampleClass!";
    }
}
